package com.example.springboot.learnjpaandhibernate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearnjpaandhibernateApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearnjpaandhibernateApplication.class, args);
	}

}
