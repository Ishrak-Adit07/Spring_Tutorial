package com.example.springboot.learnjpaandhibernate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnjpaandhibernateApplicationTests {

	@Test
	void contextLoads() {
	}

}
